package egovframework.WASTE.ntt.service;


import egovframework.WASTE.cmmn.service.SearchVO;

public class BoardAtchmnfl extends SearchVO {

	private static final long serialVersionUID = -5058414253781601823L;
	
	/** 첨부파일 번호 */
	private int atchmnflNo;
	
	/** 게시판 번호 */
	private String boardNo;
	
	/** 게시물 번호 */
	private int contentNo;
	
	/** 저장 경로 */
	private String storePath;
	
	/** 파일명 */
	private String fileNm;
	
	/** 저장 파일명 */
	private String storeFileNm;
	
	/** 본문 삽입 여부 */
	private String bdtInsrtAt;

	/** 파일 확장자 */
	private String fileExtsn;
	
	private String frstRegisterPnttm;
	private String lastUpdusrPnttm;
	
	public int getAtchmnflNo() {
		return atchmnflNo;
	}
	public void setAtchmnflNo(int atchmnflNo) {
		this.atchmnflNo = atchmnflNo;
	}
	public String getBoardNo() {
		return boardNo;
	}
	public void setBoardNo(String boardNo) {
		this.boardNo = boardNo;
	}
	public int getContentNo() {
		return contentNo;
	}
	public void setContentNo(int contentNo) {
		this.contentNo = contentNo;
	}
	public String getStorePath() {
		return storePath;
	}
	public void setStorePath(String storePath) {
		this.storePath = storePath;
	}
	public String getFileNm() {
		return fileNm;
	}
	public void setFileNm(String fileNm) {
		this.fileNm = fileNm;
	}
	public String getStoreFileNm() {
		return storeFileNm;
	}
	public void setStoreFileNm(String storeFileNm) {
		this.storeFileNm = storeFileNm;
	}
	public String getBdtInsrtAt() {
		return bdtInsrtAt;
	}
	public void setBdtInsrtAt(String bdtInsrtAt) {
		this.bdtInsrtAt = bdtInsrtAt;
	}
	
	public String getFileExtsn() {
		return fileExtsn;
	}
	public void setFileExtsn(String fileExtsn) {
		this.fileExtsn = fileExtsn;
	}
	public String getFrstRegisterPnttm() {
		return frstRegisterPnttm;
	}
	public void setFrstRegisterPnttm(String frstRegisterPnttm) {
		this.frstRegisterPnttm = frstRegisterPnttm;
	}
	public String getLastUpdusrPnttm() {
		return lastUpdusrPnttm;
	}
	public void setLastUpdusrPnttm(String lastUpdusrPnttm) {
		this.lastUpdusrPnttm = lastUpdusrPnttm;
	}
	
}
