package egovframework.WASTE.ntt.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

public interface BoardAtchmnflService {

	/**
	 * 첨부파일을 등록 한다.
	 * @param boardAtchmnfl
	 * @throws Exception
	 */
	void insertBoardAtchmnfl(BoardAtchmnfl boardAtchmnfl) throws Exception;
	
	/**
	 * 첨부파일 목록을 조회 한다.
	 * @param boardAtchmnfl
	 * @return List<BoardAtchmnflVO> 첨부파일 목록
	 * @throws Exception
	 */
	List<BoardAtchmnflVO> selectBoardAtchmnflList(BoardAtchmnfl boardAtchmnfl) throws Exception;
	
	/**
	 * 첨부파일 목록을 조회 한다.
	 * @param request
	 * @param nttNo
	 * @param resize
	 * @return List<BoardAtchmnflVO> 첨부파일 목록
	 * @throws Exception
	 */
	List<BoardAtchmnflVO> selectBoardAtchmnflList(HttpServletRequest request, int nttNo, boolean resize) throws Exception;
	
	/**
	 * 첨부파일을 삭제 한다.
	 * @param boardAtchmnfl
	 * @throws Exception
	 */
	void deleteBoardAtchmnfl(BoardAtchmnfl boardAtchmnfl) throws Exception;
	
	/**
	 * 첨부파일을 삭제 한다.
	 * @param atchmnflNo
	 * @throws Exception
	 */
	void deleteBoardAtchmnfl(int atchmnflNo) throws Exception;
	
	/**
	 * 해당 게시물의 모든 첨부파일에 대한 본문삽입을 'N'처리 한다.
	 * @param nttNo
	 * @throws Exception
	 */
	void updateBoardAtchmnflBdtInsrtAtAllN(int nttNo) throws Exception;
	
	/**
	 * 첨부파일의 본문삽일을 'Y'처리 한다.
	 * @param atchmnflNo
	 * @throws Exception
	 */
	void updateBoardAtchmnflBdtInsrtAtY(int atchmnflNo) throws Exception;
	
	/**
	 * 첨부파일을 조회 한다.
	 * @param atchmnflNo
	 * @return BoardAtchmnfl 첨부파일 상세정보
	 * @throws Exception
	 */
	BoardAtchmnfl selectBoardAtchmnfl(int atchmnflNo) throws Exception;
	
}
