package egovframework.WASTE.ntt.service;
/**
 * 게시물 첨부파일을 관리하기 위한 VO 모델 클래스
 * @author (주)한신정보기술 연구개발팀 최관형
 * @since 2014.06.06
 * @version 1.0
 * @see
 *
 * <pre>
 * << 개정이력(Modification Information) >>
 *   
 *  수정일           수정자     수정내용
 *  ------------- -------- ---------------------------
 *  2014.06.06 최관형     최초 생성
 *
 * </pre>
 */
public class BoardAtchmnflVO extends BoardAtchmnfl {
	
	private static final long serialVersionUID = -3414762886389035044L;

	/** 이미지 리사이즈 가로 */
	private int imgResizeWidth;
	
	/** 이미지 리사이즈 세로 */
	private int imgResizeHeight;

	public int getImgResizeWidth() {
		return imgResizeWidth;
	}
	public void setImgResizeWidth(int imgResizeWidth) {
		this.imgResizeWidth = imgResizeWidth;
	}
	public int getImgResizeHeight() {
		return imgResizeHeight;
	}
	public void setImgResizeHeight(int imgResizeHeight) {
		this.imgResizeHeight = imgResizeHeight;
	}

}
