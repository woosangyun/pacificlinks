package egovframework.WASTE.club.service;

import egovframework.WASTE.cmmn.FileVO;

public class ClubCodeVO extends FileVO {

	private static final long serialVersionUID = -8086612404157198972L;
	
	private String areaCode;
	private String upperCode;
	private String areaNm;
	
	public String getAreaCode() {
		return areaCode;
	}
	public void setAreaCode(String areaCode) {
		this.areaCode = areaCode;
	}
	public String getUpperCode() {
		return upperCode;
	}
	public void setUpperCode(String upperCode) {
		this.upperCode = upperCode;
	}
	public String getAreaNm() {
		return areaNm;
	}
	public void setAreaNm(String areaNm) {
		this.areaNm = areaNm;
	}

}
