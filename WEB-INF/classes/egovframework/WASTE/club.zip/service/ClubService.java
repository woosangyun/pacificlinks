package egovframework.WASTE.club.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.multipart.MultipartRequest;

public interface ClubService {

    List selectClubList(ClubVO clubVO) throws Exception;

    int selectClubListTotCnt(ClubVO clubVO);
    
    String insertClub(MultipartRequest multiRequest, HttpServletRequest request, ClubVO clubVO) throws Exception;
    
    void updateClub(MultipartHttpServletRequest multiRequest, HttpServletRequest request, ClubVO clubVO) throws Exception;
    
    void deleteClub(ClubVO clubVO) throws Exception;
    
    ClubVO selectClubData(ClubVO clubVO) throws Exception;

  }
