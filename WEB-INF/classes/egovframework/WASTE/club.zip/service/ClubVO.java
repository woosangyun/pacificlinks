package egovframework.WASTE.club.service;

import egovframework.WASTE.club.service.ClubCodeVO;

public class ClubVO extends ClubCodeVO {

	private static final long serialVersionUID = -9016334219206123864L;
	
	private int clubNo;
	private String location;
	private String clubNm;
	private String clubGbNm;
	private String linkUrl;
	private String frstRegisterPnttm;
	private String lastUpdusrPnttm;
	private String deleteAt;
	
	public int getClubNo() {
		return clubNo;
	}
	public void setClubNo(int clubNo) {
		this.clubNo = clubNo;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getClubNm() {
		return clubNm;
	}
	public void setClubNm(String clubNm) {
		this.clubNm = clubNm;
	}
	public String getClubGbNm() {
		return clubGbNm;
	}
	public void setClubGbNm(String clubGbNm) {
		this.clubGbNm = clubGbNm;
	}
	public String getLinkUrl() {
		return linkUrl;
	}
	public void setLinkUrl(String linkUrl) {
		this.linkUrl = linkUrl;
	}
	public String getFrstRegisterPnttm() {
		return frstRegisterPnttm;
	}
	public void setFrstRegisterPnttm(String frstRegisterPnttm) {
		this.frstRegisterPnttm = frstRegisterPnttm;
	}
	public String getLastUpdusrPnttm() {
		return lastUpdusrPnttm;
	}
	public void setLastUpdusrPnttm(String lastUpdusrPnttm) {
		this.lastUpdusrPnttm = lastUpdusrPnttm;
	}
	public String getDeleteAt() {
		return deleteAt;
	}
	public void setDeleteAt(String deleteAt) {
		this.deleteAt = deleteAt;
	}
		 
}
