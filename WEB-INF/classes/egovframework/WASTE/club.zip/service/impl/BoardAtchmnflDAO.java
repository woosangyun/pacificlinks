package egovframework.WASTE.ntt.service.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import egovframework.WASTE.ntt.service.BoardAtchmnfl;
import egovframework.WASTE.ntt.service.BoardAtchmnflVO;
import egovframework.rte.psl.dataaccess.EgovAbstractDAO;

@Repository("boardAtchmnflDAO")
public class BoardAtchmnflDAO extends EgovAbstractDAO {

	/**
	 * 첨부파일을 등록 한다.
	 * @param boardAtchmnfl
	 */
	public void insertBoardAtchmnfl(BoardAtchmnfl boardAtchmnfl) {
		insert("boardAtchmnflDAO.insertBoardAtchmnfl", boardAtchmnfl);
	}
	
	/**
	 * 첨부파일 목록을 조회 한다.
	 * @param boardAtchmnfl
	 * @return List<BoardAtchmnflVO> 첨부파일 목록
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	public List<BoardAtchmnflVO> selectBoardAtchmnflList(BoardAtchmnfl boardAtchmnfl) throws Exception {
		return (List<BoardAtchmnflVO>) list("boardAtchmnflDAO.selectBoardAtchmnflList", boardAtchmnfl);
	}
	
	/**
	 * 첨부파일을 삭제 한다.
	 * @param boardAtchmnfl
	 * @throws Exception
	 */
	public void deleteBoardAtchmnfl(BoardAtchmnfl boardAtchmnfl) throws Exception {
		delete("boardAtchmnflDAO.deleteBoardAtchmnfl", boardAtchmnfl);
	}
	
	/**
	 * 해당 게시물의 모든 첨부파일에 대한 본문삽입을 'N'처리 한다.
	 * @param boardAtchmnfl
	 * @throws Exception
	 */
	public void updateBoardAtchmnflBdtInsrtAtAllN(BoardAtchmnfl boardAtchmnfl) throws Exception {
		update("boardAtchmnflDAO.updateBoardAtchmnflBdtInsrtAtAllN", boardAtchmnfl);
	}
	
	/**
	 * 첨부파일의 본문삽일을 'Y'처리 한다.
	 * @param boardAtchmnfl
	 * @throws Exception
	 */
	public void updateBoardAtchmnflBdtInsrtAtY(BoardAtchmnfl boardAtchmnfl) throws Exception {
		update("boardAtchmnflDAO.updateBoardAtchmnflBdtInsrtAtY", boardAtchmnfl);
	}
	
	/**
	 * 첨부파일을 조회 한다.
	 * @param boardAtchmnfl
	 * @return
	 * @throws Exception
	 */
	public BoardAtchmnfl selectBoardAtchmnfl(BoardAtchmnfl boardAtchmnfl) throws Exception {
		return (BoardAtchmnfl) selectByPk("boardAtchmnflDAO.selectBoardAtchmnfl", boardAtchmnfl);
	}
	
}