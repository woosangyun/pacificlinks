package egovframework.WASTE.ntt.service.impl;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Service;

import egovframework.WASTE.cmmn.FileMngUtil;
import egovframework.WASTE.cmmn.ImageUtil;
import egovframework.WASTE.ntt.service.BoardAtchmnfl;
import egovframework.WASTE.ntt.service.BoardAtchmnflService;
import egovframework.WASTE.ntt.service.BoardAtchmnflVO;
import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;

@Service("boardAtchmnflService")
public class BoardAtchmnflServiceImpl extends EgovAbstractServiceImpl implements BoardAtchmnflService {
	
	/** boardAtchmnflDAO */
	@Resource(name="boardAtchmnflDAO")
	private BoardAtchmnflDAO boardAtchmnflDAO;

	/** FileMngUtil */
	@Resource(name="FileMngUtil")
	private FileMngUtil fileMngUtil;
	
	public void insertBoardAtchmnfl(BoardAtchmnfl boardAtchmnfl) throws Exception {
		boardAtchmnflDAO.insertBoardAtchmnfl(boardAtchmnfl);
	}
	
	public List<BoardAtchmnflVO> selectBoardAtchmnflList(BoardAtchmnfl boardAtchmnfl) throws Exception {
		return boardAtchmnflDAO.selectBoardAtchmnflList(boardAtchmnfl);
	}
	
	public List<BoardAtchmnflVO> selectBoardAtchmnflList(HttpServletRequest request, int contentNo, boolean resize) throws Exception {
		
		BoardAtchmnfl boardAtchmnfl = new BoardAtchmnfl();
		boardAtchmnfl.setContentNo(contentNo);
		List<BoardAtchmnflVO> boardAtchmnflList = selectBoardAtchmnflList(boardAtchmnfl);
		
		if( resize ) {
			// 본문삽입 이미지 리사이즈
			for( int i=0; i<boardAtchmnflList.size(); i++ ) {
				if( "Y".equals(boardAtchmnflList.get(i).getBdtInsrtAt()) ) {
					if( "jpg".equals(boardAtchmnflList.get(i).getFileExtsn()) || "jpeg".equals(boardAtchmnflList.get(i).getFileExtsn()) || "gif".equals(boardAtchmnflList.get(i).getFileExtsn()) 
							|| "bmp".equals(boardAtchmnflList.get(i).getFileExtsn()) || "png".equals(boardAtchmnflList.get(i).getFileExtsn())) {
						String filePath = fileMngUtil.realPath(request, boardAtchmnflList.get(i).getStorePath() + "/" + boardAtchmnflList.get(i).getStoreFileNm());
						try {
							int[] imgSize = ImageUtil.getImageSize(filePath);
							int[] fixSize = {500, 400};
							int[] reSize = ImageUtil.reSize_W(imgSize, fixSize);
							boardAtchmnflList.get(i).setImgResizeWidth(reSize[0]);
							boardAtchmnflList.get(i).setImgResizeHeight(reSize[1]);
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				}
			}
		}
		
		return boardAtchmnflList;
	}
	
	public void deleteBoardAtchmnfl(BoardAtchmnfl boardAtchmnfl) throws Exception {
		boardAtchmnflDAO.deleteBoardAtchmnfl(boardAtchmnfl);
	}
	
	public void deleteBoardAtchmnfl(int atchmnflNo) throws Exception {
		BoardAtchmnfl boardAtchmnfl = new BoardAtchmnfl();
		boardAtchmnfl.setAtchmnflNo(atchmnflNo);
		deleteBoardAtchmnfl(boardAtchmnfl);
	}
	
	public void updateBoardAtchmnflBdtInsrtAtAllN(int contentNo) throws Exception {
		BoardAtchmnfl boardAtchmnfl = new BoardAtchmnfl();
		boardAtchmnfl.setContentNo(contentNo);
		boardAtchmnflDAO.updateBoardAtchmnflBdtInsrtAtAllN(boardAtchmnfl);
	}
	
	public void updateBoardAtchmnflBdtInsrtAtY(int atchmnflNo) throws Exception {
		BoardAtchmnfl boardAtchmnfl = new BoardAtchmnfl();
		boardAtchmnfl.setAtchmnflNo(atchmnflNo);
		boardAtchmnflDAO.updateBoardAtchmnflBdtInsrtAtY(boardAtchmnfl);		
	}
	
	public BoardAtchmnfl selectBoardAtchmnfl(int atchmnflNo) throws Exception {
		BoardAtchmnfl boardAtchmnfl = new BoardAtchmnfl();
		boardAtchmnfl.setAtchmnflNo(atchmnflNo);
		return boardAtchmnflDAO.selectBoardAtchmnfl(boardAtchmnfl);
	}
	
}
