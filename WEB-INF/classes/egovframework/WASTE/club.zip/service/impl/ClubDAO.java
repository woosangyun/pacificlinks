package egovframework.WASTE.club.service.impl;

import egovframework.WASTE.club.service.ClubVO;
import egovframework.rte.psl.dataaccess.EgovAbstractDAO;
import java.util.List;
import org.springframework.stereotype.Repository;

@Repository("clubDAO")
public class ClubDAO extends EgovAbstractDAO {
    public List selectClubList(ClubVO clubVO) throws Exception {
        return list("clubDAO.selectclubList", clubVO);
    }

    public int selectClubListTotCnt(ClubVO clubVO) {
        return ((Integer) getSqlMapClientTemplate().queryForObject("clubDAO.selectClubListTotCnt", clubVO)).intValue();
    }
    
    public String insertClub(ClubVO clubVO) throws Exception {
        return (String) insert("clubDAO.insertClub", clubVO);
    }
    
    public void updateClub(ClubVO clubVO) throws Exception {
    	update("clubDAO.updateClub", clubVO);
    }
    
    public void deleteClub(ClubVO clubVO) throws Exception {
    	update("clubDAO.deleteClub", clubVO);
    }
    
    public int selectClubNoNextVal() throws Exception {
		return (Integer)selectByPk("clubDAO.selectClubNoNextVal", null);
	}
    
    public ClubVO selectClubData(ClubVO clubVO) throws Exception {
        return (ClubVO)  getSqlMapClientTemplate().queryForObject("clubDAO.selectClubData", clubVO);
    }
}
