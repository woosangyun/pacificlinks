package egovframework.WASTE.club.service.impl;


import egovframework.WASTE.cmmn.FileMngUtil;
import egovframework.WASTE.cmmn.FileVO;
import egovframework.WASTE.cmmn.StringUtil;
import egovframework.WASTE.ntt.service.BoardAtchmnfl;
import egovframework.WASTE.ntt.service.BoardAtchmnflService;
import egovframework.WASTE.club.service.ClubService;
import egovframework.WASTE.club.service.ClubVO;
import egovframework.rte.fdl.cmmn.AbstractServiceImpl;
import egovframework.rte.fdl.idgnr.EgovIdGnrService;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.multipart.MultipartRequest;

@Service("clubService")
public class ClubServiceImpl extends AbstractServiceImpl implements ClubService {
    @Resource(name = "egovIdGnrService")
    private EgovIdGnrService egovIdGnrService;
    @Resource(name = "clubDAO")
    private ClubDAO clubDAO;
    
    @Resource(name="FileMngUtil")
	private FileMngUtil fileMngUtil;
    
	/** boardAtchmnflService */
	@Resource(name="boardAtchmnflService")
	private BoardAtchmnflService boardAtchmnflService;

    public List selectClubList(ClubVO clubVO) throws Exception {
        return this.clubDAO.selectClubList(clubVO);
    }

    public int selectClubListTotCnt(ClubVO clubVO) {
        return this.clubDAO.selectClubListTotCnt(clubVO);
    }
    
    public String insertClub(MultipartRequest multiRequest, HttpServletRequest request, ClubVO clubVO) throws Exception {
    	int contentNo = 0;
    	contentNo = clubDAO.selectClubNoNextVal();
    	clubVO.setContentNo(contentNo);
    	
    	/* 첨부파일 등록 */
		String BBS_STORE_PATH = "/home/PacificLinks/data/club/";
		String BBS_NTT_STORE_PATH = BBS_STORE_PATH + clubVO.getBoardNo();
		String BBS_NTT_THUMB_STORE_PATH = BBS_NTT_STORE_PATH + "/thumb";
		String bbsDir = fileMngUtil.realPath(request, BBS_STORE_PATH);
		String bbsNttDir = fileMngUtil.realPath(request, BBS_NTT_STORE_PATH);
		String bbsNttThumnDir = fileMngUtil.realPath(request, BBS_NTT_THUMB_STORE_PATH);
		fileMngUtil.mkdir(bbsDir);
		fileMngUtil.mkdir(bbsNttDir);
		fileMngUtil.mkdir(bbsNttThumnDir);
		
		String[] arrFileType = "gif,jpg,png,bmp".split(",");
		long maxFileSize = 30 * 1024 * 1024;
		// 유효성 검사 및 저장
		List<FileVO> fileVOList = fileMngUtil.parseFileInfMulti(multiRequest.getFiles("atchmnfl"), bbsNttDir, maxFileSize, arrFileType, null, "", null);

		for( int i=0; i<fileVOList.size(); i++ ) {
			BoardAtchmnfl bbsAtchmnfl = new BoardAtchmnfl();
			bbsAtchmnfl.setBoardNo(clubVO.getBoardNo());  // 게시판 번호
			bbsAtchmnfl.setContentNo(clubVO.getContentNo());  // 게시물 번호
			bbsAtchmnfl.setStorePath(BBS_STORE_PATH + clubVO.getBoardNo());  // 저장경로
			bbsAtchmnfl.setFileNm(fileVOList.get(i).getOrignlFileNm());  // 파일명
			bbsAtchmnfl.setStoreFileNm(fileVOList.get(i).getStreFileNm());  // 저장파일명		
			bbsAtchmnfl.setFrstRegisterPnttm(clubVO.getFrstRegisterPnttm());		
			bbsAtchmnfl.setFileExtsn(fileVOList.get(i).getFileExtsn());
			
			boardAtchmnflService.insertBoardAtchmnfl(bbsAtchmnfl);
			
			// 이미지 변환이면
//  			if( "Y".equals(bbsInfo.getImageUseAt()) ) {
//  				ImageUtil.createThumb(fileMngUtil.realPath(request, BBS_NTT_STORE_PATH + "/" + bbsAtchmnfl.getStoreFileNm()), 
//  						fileMngUtil.realPath(request, BBS_NTT_THUMB_STORE_PATH + "/t_" + bbsAtchmnfl.getStoreFileNm()), 
//  						bbsInfo.getThumbSizeWidth(), bbsInfo.getThumbSizeHeight(), "FIX");
//  			}   
		}
		return this.clubDAO.insertClub(clubVO);
    }
    
    public void updateClub(MultipartHttpServletRequest multiRequest, HttpServletRequest request, ClubVO clubVO) throws Exception {   
    	
    	/* 첨부파일 삭제 */
		for( int i=0; i<5; i++ ) {
			String fileProcTy = request.getParameter("fileProcTy" + i);
			if( !StringUtil.isEmpty(fileProcTy) ) {
				if( !"U".equals(fileProcTy) ) {
					boardAtchmnflService.deleteBoardAtchmnfl(Integer.valueOf(fileProcTy));
				}
			}
		}
		
		/* 첨부파일 등록 */
		String BBS_STORE_PATH = "/home/PacificLinks/data/club/";
		String BBS_NTT_STORE_PATH = BBS_STORE_PATH + clubVO.getBoardNo();
		String BBS_NTT_THUMB_STORE_PATH = BBS_NTT_STORE_PATH + "/thumb";
		String bbsDir = fileMngUtil.realPath(request, BBS_STORE_PATH);
		String bbsNttDir = fileMngUtil.realPath(request, BBS_NTT_STORE_PATH);
		String bbsNttThumnDir = fileMngUtil.realPath(request, BBS_NTT_THUMB_STORE_PATH);
		fileMngUtil.mkdir(bbsDir);
		fileMngUtil.mkdir(bbsNttDir);
		fileMngUtil.mkdir(bbsNttThumnDir);
		
		String[] arrFileType = "gif,jpg,png,bmp".split(",");
		long maxFileSize = 30 * 1024 * 1024;
		// 유효성 검사 및 저장
		List<FileVO> fileVOList = fileMngUtil.parseFileInfMulti(multiRequest.getFiles("atchmnfl"), bbsNttDir, maxFileSize, arrFileType, null, "", null);

		for( int i=0; i<fileVOList.size(); i++ ) {
			BoardAtchmnfl bbsAtchmnfl = new BoardAtchmnfl();
			bbsAtchmnfl.setBoardNo(clubVO.getBoardNo());  // 게시판 번호
			bbsAtchmnfl.setContentNo(clubVO.getContentNo());  // 게시물 번호
			bbsAtchmnfl.setStorePath(BBS_STORE_PATH + clubVO.getBoardNo());  // 저장경로
			bbsAtchmnfl.setFileNm(fileVOList.get(i).getOrignlFileNm());  // 파일명
			bbsAtchmnfl.setStoreFileNm(fileVOList.get(i).getStreFileNm());  // 저장파일명		
			bbsAtchmnfl.setFrstRegisterPnttm(clubVO.getLastUpdusrPnttm());		
			bbsAtchmnfl.setFileExtsn(fileVOList.get(i).getFileExtsn());
			
			boardAtchmnflService.insertBoardAtchmnfl(bbsAtchmnfl);
			
			// 이미지 변환이면
//  			if( "Y".equals(bbsInfo.getImageUseAt()) ) {
//  				ImageUtil.createThumb(fileMngUtil.realPath(request, BBS_NTT_STORE_PATH + "/" + bbsAtchmnfl.getStoreFileNm()), 
//  						fileMngUtil.realPath(request, BBS_NTT_THUMB_STORE_PATH + "/t_" + bbsAtchmnfl.getStoreFileNm()), 
//  						bbsInfo.getThumbSizeWidth(), bbsInfo.getThumbSizeHeight(), "FIX");
//  			}   
		}
    	
    	this.clubDAO.updateClub(clubVO);
    }
    
    public void deleteClub(ClubVO clubVO) throws Exception {    	
    	this.clubDAO.deleteClub(clubVO);
    }
    
    public ClubVO selectClubData(ClubVO clubVO) throws Exception {
        return this.clubDAO.selectClubData(clubVO);
    }
}
