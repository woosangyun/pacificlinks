package egovframework.WASTE.club.web;

import egovframework.WASTE.cmmn.DateUtil;
import egovframework.WASTE.cmmn.service.CmmUseService;
import egovframework.WASTE.cmmn.service.SearchVO;

import egovframework.WASTE.utl.fcc.service.EgovStringUtil;
import egovframework.WASTE.ntt.service.BoardAtchmnflService;
import egovframework.WASTE.ntt.service.BoardAtchmnflVO;
import egovframework.WASTE.club.service.ClubService;
import egovframework.WASTE.club.service.ClubVO;
import egovframework.rte.fdl.property.EgovPropertyService;
import egovframework.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;

import java.net.InetAddress;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
//
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springmodules.validation.commons.DefaultBeanValidator;
import org.apache.commons.lang.StringEscapeUtils;

@SessionAttributes(types = {ClubVO.class})
@Controller
public class ClubController {
    @Resource(name = "beanValidator")
    protected DefaultBeanValidator beanValidator;
    @Resource(name = "cmmUseService")
    private CmmUseService cmmUseService;
    protected Log log = LogFactory.getLog(getClass());
    @Resource(name = "propertiesService")
    protected EgovPropertyService propertiesService;
    @Resource(name = "clubService")
    private ClubService clubService;
    /** boardAtchmnflService */
	@Resource(name="boardAtchmnflService")
	private BoardAtchmnflService boardAtchmnflService;

    @RequestMapping({"/selectBoardList.do"})
    public String selectBoardList(@ModelAttribute("searchVO") SearchVO searchVO, ModelMap model, 
    		HttpSession session, HttpServletRequest request, @RequestParam("boardNo") String boardNo) throws Exception {
        this.log.debug("# Controller - selectBoardList START!");
        session.setAttribute("menu", "selectBoardList");
          
        String gubun = (String) request.getSession().getAttribute("userNM");

        ClubVO clubVO = new ClubVO();
        String pageUnit = request.getParameter("pageUnit");
        
        if (pageUnit == null || EgovStringUtil.EMPTY.equals(pageUnit)) {
            pageUnit = new StringBuilder(String.valueOf(this.propertiesService.getInt("pageUnit"))).toString();
        }
        
        if("prom".equals(boardNo) || "promPd".equals(boardNo)) {
            System.out.println(":::::::::::::::::::pageUnit: "+pageUnit);
            if("10".equals(pageUnit)) {
            	pageUnit = "6";
            }
        }
        
        clubVO.setPageUnit(Integer.parseInt(pageUnit));
        clubVO.setSearchKeyword(request.getParameter("searchKeyword"));
        clubVO.setSearchCondition(request.getParameter("searchCondition"));
        clubVO.setPageSize(this.propertiesService.getInt("pageSize"));
        PaginationInfo paginationInfo = new PaginationInfo();
        String pageIndex = request.getParameter("pageNo");
        if (pageIndex == null || EgovStringUtil.EMPTY.equals(pageIndex)) {
        	clubVO.setPageIndex(1);
        } else {
        	clubVO.setPageIndex(Integer.parseInt(pageIndex));
        }
        model.addAttribute("pageIndex", Integer.valueOf(clubVO.getPageIndex()));
        paginationInfo.setCurrentPageNo(clubVO.getPageIndex());
        paginationInfo.setRecordCountPerPage(clubVO.getPageUnit());
        paginationInfo.setPageSize(clubVO.getPageSize());
        clubVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
        clubVO.setLastIndex(paginationInfo.getLastRecordIndex());
        clubVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());
        clubVO.setBoardNo(boardNo);
        
//        if("prom".equals(boardNo) || "promPd".equals(boardNo)) {
//        	System.out.println("::::::::::::::::prom page size: "+clubVO.getRecordCountPerPage());
//        	if(clubVO.getRecordCountPerPage() == 10) {
//        		clubVO.setRecordCountPerPage(6);
//        		paginationInfo.setPageSize(6);
//        	}
//        }
//        
        // 게시판 번호
     	model.addAttribute("boardNo", boardNo);
     	
        model.addAttribute("resultList", this.clubService.selectClubList(clubVO));
        model.addAttribute("clubVO", clubVO);
        
        paginationInfo.setTotalRecordCount(this.clubService.selectClubListTotCnt(clubVO));
        
        model.addAttribute("paginationInfo", paginationInfo);
        model.addAttribute("pageUnit", pageUnit);
        
        List<BoardAtchmnflVO> boardAtchmnflList = boardAtchmnflService.selectBoardAtchmnflList(request, clubVO.getContentNo(), true);
		model.addAttribute("boardAtchmnflList", boardAtchmnflList);
        
        return "/ntt/boardList_"+boardNo;
    }
    
    @RequestMapping({"/pl/mngBoardList.do"})
    public String mngBoardList(@ModelAttribute("searchVO") SearchVO searchVO, ModelMap model, HttpSession session, 
    		HttpServletRequest request, @RequestParam("boardNo") String boardNo) throws Exception {
    	this.log.debug("# Controller - mngBoardList START!");
    	session.setAttribute("menu", "mngBoardList");
    	if (request.getSession().getAttribute("loginVO") == null) {
            return "/uat/loginMngView";
        }
    	String gubun = (String) request.getSession().getAttribute("userNM");
    	
    	ClubVO clubVO = new ClubVO();
    	String pageUnit = request.getParameter("pageUnit");
    	clubVO.setSearchKeyword(request.getParameter("searchKeyword"));
        clubVO.setSearchCondition(request.getParameter("searchCondition"));
    	if (pageUnit == null || EgovStringUtil.EMPTY.equals(pageUnit)) {
    		pageUnit = new StringBuilder(String.valueOf(this.propertiesService.getInt("pageUnit"))).toString();
    	}
    	clubVO.setPageUnit(Integer.parseInt(pageUnit));
    	clubVO.setPageSize(this.propertiesService.getInt("pageSize"));
    	PaginationInfo paginationInfo = new PaginationInfo();
    	String pageIndex = request.getParameter("pageNo");
    	if (pageIndex == null || EgovStringUtil.EMPTY.equals(pageIndex)) {
    		clubVO.setPageIndex(1);
    	} else {
    		clubVO.setPageIndex(Integer.parseInt(pageIndex));
    	}
    	model.addAttribute("pageIndex", Integer.valueOf(clubVO.getPageIndex()));
    	paginationInfo.setCurrentPageNo(clubVO.getPageIndex());
    	paginationInfo.setRecordCountPerPage(clubVO.getPageUnit());
    	paginationInfo.setPageSize(clubVO.getPageSize());
    	clubVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
    	clubVO.setLastIndex(paginationInfo.getLastRecordIndex());
    	clubVO.setBoardNo(boardNo);
    	clubVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());
    	
	    // 게시판 번호
		model.addAttribute("boardNo", boardNo);
    	
    	model.addAttribute("resultList", this.clubService.selectClubList(clubVO));
    	model.addAttribute("clubVO", clubVO);
    	paginationInfo.setTotalRecordCount(this.clubService.selectClubListTotCnt(clubVO));

    	model.addAttribute("paginationInfo", paginationInfo);
        model.addAttribute("pageUnit", pageUnit);
        
        List<BoardAtchmnflVO> boardAtchmnflList = boardAtchmnflService.selectBoardAtchmnflList(request, clubVO.getContentNo(), true);
		model.addAttribute("boardAtchmnflList", boardAtchmnflList);
        
    	return "/ntt/pl/mngBoardList";
    }   
    
    @RequestMapping({"/pl/addClubView.do"})
    public String addClubView(@ModelAttribute("searchVO") SearchVO searchVO, HttpSession session, 
    		HttpServletRequest request, Model model, @RequestParam("boardNo") String boardNo) throws Exception {
    	if (request.getSession().getAttribute("loginVO") == null) {
            return "/uat/loginMngView";
        }
    	
    	// 게시판 번호
    	model.addAttribute("boardNo", boardNo);
    	return "/ntt/pl/clubRegist";
    }
    
    @RequestMapping({"/pl/addClub.do"})
    public String addClub(@ModelAttribute("searchVO") SearchVO searchVO, BindingResult bindingResult, Model model, 
    		final MultipartHttpServletRequest multiRequest, SessionStatus status, @RequestParam("clubNo") int clubNo) throws Exception {
        this.log.debug("# Controller - addClub START!");
        if (multiRequest.getSession().getAttribute("loginVO") == null) {
            return "/uat/loginMngView";
        }
        ClubVO clubVO = new ClubVO();
      
        clubVO.setClubNo(clubNo);        
        clubVO.setAreaCode(multiRequest.getParameter("areaCode"));
        clubVO.setLocation(multiRequest.getParameter("location"));
        clubVO.setClubNm(multiRequest.getParameter("clubNm"));
        clubVO.setClubGbNm(multiRequest.getParameter("clubGbNm"));        
        clubVO.setLinkUrl(multiRequest.getParameter("linkUrl"));        
        clubVO.setFrstRegisterPnttm(DateUtil.getNowDateTime("yyyyMMddHHmmss"));
        clubVO.setDeleteAt("N");
        
        this.beanValidator.validate(clubVO, bindingResult);
        if (bindingResult.hasErrors()) {
            model.addAttribute("clubVO", clubVO);
            return this.cmmUseService.redirectMsg(model, "등록 중 오류가 발생했습니다.", multiRequest.getContextPath() + "/pl/addClubView.do?boardNo="+clubNo);
        }
        this.clubService.insertClub(multiRequest,multiRequest,clubVO);
               
        status.setComplete();
        return this.cmmUseService.redirectMsg(model, "등록이 완료되었습니다.", multiRequest.getContextPath() + "/pl/mngBoardList.do?boardNo="+clubNo);
    }
     
    
    @RequestMapping({"/pl/mngBoardView.do"})
    public String mngBoardView(@ModelAttribute("searchVO") SearchVO searchVO, HttpServletRequest request, Model model,     	
    		@RequestParam("boardNo") String boardNo, @RequestParam("contentNo") String contentNo) throws Exception {
        this.log.debug("# Controller - mngBoardView START!");
        if (request.getSession().getAttribute("loginVO") == null) {
            return "/uat/loginMngView";
        }
        ClubVO clubVO = new ClubVO();
        clubVO.setContentNo(Integer.parseInt(contentNo));

        ClubVO clubResult = new ClubVO();
        clubResult = this.clubService.selectClubData(clubVO);
        
     // 첨부파일 목록
	List<BoardAtchmnflVO> boardAtchmnflList = boardAtchmnflService.selectBoardAtchmnflList(request, clubVO.getContentNo(), false);
	model.addAttribute("boardAtchmnflList", boardAtchmnflList);
        
        // 게시판 번호
    	model.addAttribute("boardNo", boardNo);
        
        model.addAttribute("clubResult", clubResult);
        
        return "/ntt/pl/mngBoardView";
    }
   
    @RequestMapping({"/pl/updateClub.do"})
    public String updateClub(@ModelAttribute("searchVO") SearchVO searchVO, BindingResult bindingResult, Model model, 
    		final MultipartHttpServletRequest multiRequest, SessionStatus status, @RequestParam("clubNo") int clubNo) throws Exception {
        this.log.debug("# Controller - updateClub START!");
        if (multiRequest.getSession().getAttribute("loginVO") == null) {
            return "/uat/loginMngView";
        }
        String contentNo = multiRequest.getParameter("contentNo");
        
        ClubVO clubVO = new ClubVO();
        
        clubVO.setClubNo(clubNo);        
        clubVO.setAreaCode(multiRequest.getParameter("areaCode"));
        clubVO.setLocation(multiRequest.getParameter("location"));
        clubVO.setClubNm(multiRequest.getParameter("clubNm"));
        clubVO.setClubGbNm(multiRequest.getParameter("clubGbNm"));        
        clubVO.setLinkUrl(multiRequest.getParameter("linkUrl"));                
        clubVO.setDeleteAt("N");
        clubVO.setLastUpdusrPnttm(DateUtil.getNowDateTime("yyyyMMddHHmmss"));        
        this.beanValidator.validate(clubVO, bindingResult);
        if (bindingResult.hasErrors()) {
            model.addAttribute("clubVO", clubVO);
            return this.cmmUseService.redirectMsg(model, "수정 중 오류가 발생했습니다.", multiRequest.getContextPath() + "/pl/mngBoardView.do?boardNo="+boardNo+"&contentNo="+contentNo);
        }
        this.clubService.updateClub(multiRequest,multiRequest,clubVO);
               
        status.setComplete();
        return this.cmmUseService.redirectMsg(model, "수정이 완료되었습니다.", multiRequest.getContextPath() + "/pl/mngBoardView.do?boardNo="+boardNo+"&contentNo="+contentNo);
    }
    
    @RequestMapping({"/pl/deleteClub.do"})
    public String deleteClub(@ModelAttribute("searchVO") SearchVO searchVO, BindingResult bindingResult, Model model, 
    		HttpServletRequest request, SessionStatus status, @RequestParam("clubNo") int clubNo) throws Exception {
    	this.log.debug("# Controller - deleteClub START!");
    	if (request.getSession().getAttribute("loginVO") == null) {
            return "/uat/loginMngView";
        }
    	ClubVO clubVO = new ClubVO();
    	
    	clubVO.setClubNo(clubNo);              
    	clubVO.setDeleteAt("Y");
    	
    	this.beanValidator.validate(clubVO, bindingResult);
    	if (bindingResult.hasErrors()) {
    		model.addAttribute("clubVO", clubVO);
    		if("cons".equals(clubVO.getBoardNo())) {
    			return this.cmmUseService.redirectMsg(model, "삭제 중 오류가 발생했습니다.", request.getContextPath() + "/pl/mngConsView.do?boardNo="+boardNo+"&contentNo="+clubNo);
    		}
    		else {
    			return this.cmmUseService.redirectMsg(model, "삭제 중 오류가 발생했습니다.", request.getContextPath() + "/pl/mngBoardView.do?boardNo="+boardNo+"&contentNo="+clubNo);
    		}
    	}
    	this.clubService.deleteClub(clubVO);
    	
    	status.setComplete();
    	if("cons".equals(clubVO.getBoardNo())) {
    		return this.cmmUseService.redirectMsg(model, "삭제가 완료되었습니다.", request.getContextPath() + "/pl/mngConsList.do?clubNo="+clubNo);
    	} else {
    		return this.cmmUseService.redirectMsg(model, "삭제가 완료되었습니다.", request.getContextPath() + "/pl/mngBoardList.do?clubNo="+clubNo);
    	}
    }   
}
